#!/system/bin/sh

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
sleep 2
  ui_print " ———————————————————————————————— "
sleep 0.5                              
  ui_print " ░██████╗░░█████╗░███╗░░░███╗███████╗
██╔════╝░██╔══██╗████╗░████║██╔════╝
██║░░██╗░███████║██╔████╔██║█████╗░░
██║░░╚██╗██╔══██║██║╚██╔╝██║██╔══╝░░
╚██████╔╝██║░░██║██║░╚═╝░██║███████╗
░╚═════╝░╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝

░██████╗██████╗░███████╗███████╗██████╗░
██╔════╝██╔══██╗██╔════╝██╔════╝██╔══██╗
╚█████╗░██████╔╝█████╗░░█████╗░░██║░░██║
░╚═══██╗██╔═══╝░██╔══╝░░██╔══╝░░██║░░██║
██████╔╝██║░░░░░███████╗███████╗██████╔╝
╚═════╝░╚═╝░░░░░╚══════╝╚══════╝╚═════╝░"
sleep 0.5
  ui_print " ———————————————————————————————— "
  ui_print "   "
  ui_print "  "
  ui_print "- "

sleep 2

ui_print " INSTALL MODULE "
unzip -o "$ZIPFILE" 'listgame.txt' -d $MODPATH >&2

sleep 3

ui_print " List Game For GAMESPEED " 

counter=1
package_list=$(cmd package list packages | cut -f 2 -d ":")
while IFS= read -r listgame || [[ -n "$listgame" ]]; do
line=$(echo "$listgame" | awk '!/ /')
    if echo "$package_list" | grep -q "$line"; then
        ui_print "  $counter. $line"
        counter=$((counter + 1))
    else
        sed -i "/$line/d" "$MODPATH/listgame.txt"
    fi
done < "$MODPATH/listgame.txt"
ui_print " Jika Game Tidak ada Di list bisa di tambahkan manual "
ui_print " Edit listgame.txt add and install ulang "

sleep 2

ui_print "- Extracting module files GPROA"
mkdir -p $MODPATH/system/bin
unzip -o "$ZIPFILE" 'GPROA' -d $MODPATH/system/bin >&2
chmod +x $MODPATH/system/bin/GPROA

sleep 1

ui_print "- Extracting module files GAMESPEED"
mkdir -p $MODPATH/system/bin
unzip -o "$ZIPFILE" 'GAMESPEED' -d $MODPATH/system/bin >&2
chmod +x $MODPATH/system/bin/GAMESPEED

sleep 2

ui_print "-----------[succsess]-------------- "
sleep 1

  ui_print "Joined to my channel for next update "
  ui_print "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||" 
   ui_print "  @ZxyonQiy | @ZxyonQiyChnnel  "