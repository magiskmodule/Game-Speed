#!/system/bin/sh

#Credit : @ZxyonQiy |Arsene| My Channel @ZxyonQiyChnnel

sleep 3
nohup GAMESPEED > /dev/null 2>&1 &